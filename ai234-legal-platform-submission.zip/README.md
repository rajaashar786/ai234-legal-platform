# Legal Intelligence Platform (AI-234)

An AI-powered platform that lets users upload legal documents (contracts, NDAs, service agreements) and ask natural-language questions about their content. The system retrieves relevant clauses and generates accurate, source-attributed answers using Retrieval-Augmented Generation (RAG).

## Features Implemented

- **Document Upload & Processing** — accepts PDF, DOCX, and TXT files, splits them into semantic chunks
- **Vector Embeddings & Semantic Search** — uses HuggingFace sentence embeddings (`all-mpnet-base-v2`) with a FAISS vector index for fast similarity search
- **AI Legal Copilot** — a RAG pipeline that answers natural-language questions about uploaded documents, citing source documents for every answer
- **Document Storage** — uploaded document metadata (filename, chunk count, upload timestamp) is persisted in PostgreSQL
- **Containerized Infrastructure** — PostgreSQL, Neo4j, and Redis run via Docker Compose, ready for future extension (knowledge graph, caching)

## Tech Stack

| Layer | Technology |
|---|---|
| Backend Framework | FastAPI |
| LLM Orchestration | LangChain (LCEL) |
| LLM Provider | OpenRouter (`openai/gpt-oss-20b:free`) |
| Embeddings | HuggingFace Sentence Transformers |
| Vector Store | FAISS |
| Relational DB | PostgreSQL |
| Graph DB | Neo4j (provisioned, not yet integrated) |
| Cache | Redis (provisioned, not yet integrated) |
| Containerization | Docker Compose |

## Architecture

```
                    ┌─────────────────┐
   Upload File ───▶ │   FastAPI App    │
                    └────────┬─────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
      ┌───────────────┐ ┌─────────┐ ┌──────────────┐
      │ Document       │ │ FAISS   │ │ PostgreSQL   │
      │ Chunking       │ │ Vector  │ │ (metadata)   │
      │ (LangChain)    │ │ Index   │ │              │
      └───────────────┘ └────┬────┘ └──────────────┘
                              │
   Ask Question ─────────────┤
                              ▼
                       ┌─────────────┐
                       │ RAG Chain   │
                       │ (Retriever  │
                       │  + LLM)     │
                       └──────┬──────┘
                              ▼
                      Answer + Sources
```

## Project Structure

```
ai234-legal-platform/
├── app/
│   ├── main.py                 # FastAPI entry point
│   ├── config.py                # Environment settings
│   ├── database.py               # PostgreSQL session/engine setup
│   ├── api/v1/documents.py       # Upload & Ask endpoints
│   ├── core/
│   │   ├── embeddings.py         # Document loading & chunking
│   │   ├── vector_store.py       # FAISS index management
│   │   └── rag.py                # RAG chain (retrieval + LLM)
│   └── models/db_models.py       # SQLAlchemy models
├── docker-compose.yml            # Postgres, Neo4j, Redis
├── requirements.txt
└── .env                          # Environment variables (not committed)
```

## Setup & Running Locally

**Prerequisites:** Python 3.12, Docker Desktop, an OpenRouter API key (free at openrouter.ai)

1. Clone/copy the project and create a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Create a `.env` file in the project root:
   ```
   DATABASE_URL=postgresql://legaluser:legalpass@localhost:5432/legaldb
   NEO4J_URI=bolt://localhost:7687
   NEO4J_USER=neo4j
   NEO4J_PASSWORD=legalpass
   REDIS_URL=redis://localhost:6379/0
   OPENROUTER_API_KEY=your_key_here
   ```

3. Start the supporting databases:
   ```
   docker compose up -d
   ```

4. Run the API server:
   ```
   uvicorn app.main:app --reload
   ```

5. Open the interactive API docs at `http://127.0.0.1:8000/docs`

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/documents/upload` | Upload a document (PDF/DOCX/TXT), chunk it, embed it, and store metadata in PostgreSQL |
| POST | `/api/v1/documents/ask` | Ask a natural-language question; returns an AI-generated answer with source document references |

## Example Usage

**Upload:**
```
POST /api/v1/documents/upload
→ { "message": "Indexed contract.txt – 12 chunks added", "document_id": 1 }
```

**Ask:**
```
POST /api/v1/documents/ask?question=What are the payment terms in this agreement?
→ {
    "answer": "Total fee: USD 180,000, payable in monthly installments of USD 15,000...",
    "sources": ["uploads/contract.txt", ...]
  }
```

## Future Work

The following modules from the full case study specification are designed for but not yet implemented, given project timeline constraints:

- **Clause Extraction Engine** — structured extraction of individual clause types (payment, termination, liability) into the database
- **Contract Risk Intelligence** — automated risk scoring per clause
- **Knowledge Graph** — populating Neo4j with relationships between contracts, parties, and obligations
- **Compliance Engine** — comparing contracts against internal policy documents
- **Executive Dashboard** — a frontend visualizing contract status, expiring agreements, and risk distribution
- **Obligation Tracking** — automated extraction and monitoring of renewal dates and deadlines

## Notes

- The vector index (FAISS) is cumulative across uploads within a session — all uploaded documents are searchable together via the Ask endpoint.
- Neo4j and Redis containers are provisioned via Docker Compose and available for future integration but are not currently used by the application logic.